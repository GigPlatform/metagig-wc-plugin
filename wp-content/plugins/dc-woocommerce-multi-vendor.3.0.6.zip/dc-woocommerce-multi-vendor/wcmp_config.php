<?php
define('WCMp_PLUGIN_TOKEN', 'wcmp');

define('WCMp_TEXT_DOMAIN', 'dc-woocommerce-multi-vendor');

define('WCMp_PLUGIN_VERSION', '3.0.6');

define('WCMP_SCRIPT_DEBUG', false);
